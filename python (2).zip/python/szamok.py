elso_szam= 10
masodik_szam= 3.0
osszeg= elso_szam + masodik_szam
kivonas= elso_szam - masodik_szam
szorzas= elso_szam * masodik_szam
osztas= elso_szam / masodik_szam

print(osszeg,   type(osszeg))
print(kivonas,  type(osszeg))
print(szorzas,  type(osszeg))
print(osztas,   type(osszeg))