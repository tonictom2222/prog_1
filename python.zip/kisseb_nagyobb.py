szam1=int(input("adj meg egy számot: "))
szam2=int(input('adj meg még egy számot: '))
if szam1>szam2:
    print(szam1,">",szam2)
elif szam1<szam2:
    print(szam1,"<",szam2)
else:
    print(szam1,"=",szam2)