hp = "Harry Potter"

print("1. " + hp + " és a bölcsek köve")
print("2. " + hp + " és a titkok kamrája")
print("3. " + hp + " és az azkabani fogoly")
print("4. " + hp + " és a tűz serlege")
print("5. " + hp + " és a félvér herceg")
print("6. " + hp + " és a félvér herceg")
print("7. " + hp + " és a halál ereklyéi")
