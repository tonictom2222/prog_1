szam1=int(input('elsö szám:'))
szam2=int(input('második szám:'))
muvelet=input('művelet:')
if muvelet=='/':
    print('osztás')
    print('eredmény:',szam1//szam2)
    print('maradék:',szam1%szam2)