pontszam=int(input('maximális elérhetö pontszám:'))
elert=int(input('elért pontszam:  '))
ponthatar=pontszam/0.85
if ponthatar<elert
print(5-öst kaptál)